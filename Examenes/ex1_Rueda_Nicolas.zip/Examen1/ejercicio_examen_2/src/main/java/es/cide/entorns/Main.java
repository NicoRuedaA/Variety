package es.cide.entorns;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);
        String texto = " ";
        texto = sc.nextLine();

        String[] textArray = texto.split("");
        int contador = 0;
        String[] textInvertitArrat = new String[999999999];

        for (int i = textArray.length-1; i >= 0; i--) {
            //System.out.println(textArray[i]); 
            textInvertitArrat[contador] = textArray[i]; 
            System.out.print(textInvertitArrat[contador]);
            contador++;
        }
//System.out.print(textInvertitArrat[contador]);

        //System.out.println(textInvertitArrat.toString());

        /*while(!fi){
            textInvertit*=10;
            textInvertit += (text%10);
            text = text/10;

            if(text/10==0) fi = true;
        }

                    textInvertit*=10;
            textInvertit += (text%10);


        System.out.println(textInvertit);*/


        
        sc.close();
    }
}